#!/bin/sh

###################################
# set environment on my workstation
#export LD_LIBRARY_PATH=/usr/lib/oracle/xe/app/oracle/product/10.2.0/server/lib::/usr/local/lib
#. /usr/lib/oracle/xe/app/oracle/product/10.2.0/server/bin/oracle_env.sh
#export TNS_ADMIN=/home/aubert
#CRN_HOME=/home/aubert/RNPickerEnv/new-env
###################################
# set environement on dls013 dlw004
export ORACLE_HOME=/cots/oracle/oracle-10.2
export LD_LIBRARY_PATH=$ORACLE_HOME/lib
#export TNS_ADMIN=/home/smd/aubert
export TNS_ADMIN=$ORACLE_HOME/network/admin
CRN_HOME=/home/smd/aubert/public

logging_dir=/tmp/cronlogs
mkdir -p $logging_dir

begin_date=`date +"%m-%d-%yT%T"`
output="$logging_dir/log_output_$begin_date.log"

echo "Starting Run at $begin_date" >> $output
echo "Starting Run at $begin_date"

echo "outputs for this run are in $output"
#echo "outputs for this run are in $output" >> $output

#$CRN_HOME/generate_products_and_email -g test >> $output 2>&1
#$CRN_HOME/generate_products_and_email -g test 
$CRN_HOME/generate_products_and_email -g prod
result="$?"

end_date=`date +"%m-%d-%yT%T"`

echo "Stopping Run at $end_date. result=$result (0 success,other fail)."
echo "Stopping Run at $end_date. result=$result (0 success,other fail)." >> $output

exit $result
